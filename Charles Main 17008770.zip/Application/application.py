## [Imports]
import cv2, sys, face_recognition, imutils, threading, random, time, numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
from keras.preprocessing.image import img_to_array
from keras.models import load_model
from collections import Counter
skillLevel = 10
confidenceLevel = 0
correctCounter = 0
wrongCounter = 0

## [Camera Stream]
class ThreadCamView(QtCore.QThread):
    changePixmap = QtCore.pyqtSignal(QtGui.QImage)
        
    def run(self):
        video_capture = cv2.VideoCapture(1)
        global ret
        global frame
        while True:
            ret, frame = video_capture.read()
            # display on login screen
            rgbImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgbImage.shape
            bytesPerLine = ch * w
            convertToQtFormat = QtGui.QImage(rgbImage.data, w, h, bytesPerLine, QtGui.QImage.Format_RGB888)
            loginRet = convertToQtFormat.scaled(140, 80, QtCore.Qt.KeepAspectRatio)
            self.changePixmap.emit(loginRet)

## [Thread Facial Recognition]
class ThreadFaceRecognition(QtCore.QThread):
    changeUser = QtCore.pyqtSignal(str,str,str,int)
    updateEmotion = QtCore.pyqtSignal(str)

    avgEmotion = []
    
    def most_frequent(List): 
        occurence_count = Counter(List) 
        return occurence_count.most_common(1)[0][0]

    def run(self):
        # read in all data and prepare facial recognition lists
        file = open("data.txt","r")
        studentSkillLev = "0"
        age = "NULL"
        known_face_encodings = []
        known_faces_imageUrls = []
        known_face_names = []
        known_face_ages = []
        known_face_skill_levels = []
        # set up lists and variables for facial recogntion 
        face_locations = []
        face_encodings = []
        face_names = []
        process_this_frame = True
        font = cv2.FONT_HERSHEY_COMPLEX_SMALL
        confidence = 0
        ckname = "NULL"
        ckNull = 0
        user = "NULL"
          
        for line in file:
          fields = line.split(";")
          studentName = fields[0]
          studentAge = fields[1]
          studentSkillLev = fields[2]
          studentImgLocation = fields[3]

          student_image = face_recognition.load_image_file(studentImgLocation)
          student_face_encoding = face_recognition.face_encodings(student_image)[0]
          known_face_encodings.append(student_face_encoding)
          known_face_names.append(studentName)
          known_face_ages.append(studentAge)
          known_face_skill_levels.append(studentSkillLev)
          known_faces_imageUrls.append(studentImgLocation)
        file.close()
        studentSkillLev = "0"
        
        # parameters for loading data and images
        detection_model_path = 'haarcascade_frontalface_default.xml'
        emotion_model_path = '_mini_XCEPTION.102-0.66.hdf5'
       
        # loading models
        face_detection = cv2.CascadeClassifier(detection_model_path)
        emotion_classifier = load_model(emotion_model_path, compile=False)
        EMOTIONS = ["angry" ,"disgust","scared", "happy", "sad", "surprised", "neutral"]
        highestEmotion = "NULL"
        avgEmotion = []
        firstElement = 1

        # perform recognition
        while True:
            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
            face_names = []
            for face_encoding in face_encodings:
                 matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                 name = "NULL"
                 ckNull = 0
                 # allocate users             
                 if True in matches:
                     first_match_index = matches.index(True)
                     name = known_face_names[first_match_index]
                     if(name == ckname):
                         confidence = confidence + 10
                         if(confidence >= 100):
                             studentSkillLev = known_face_skill_levels[first_match_index]
                             if skillLevel != "0":                                 
                                 if int(skillLevel) != int(known_face_skill_levels[first_match_index]): # UPDATE TEXT FILE
                                    studentSkillLev = skillLevel
                                    known_face_skill_levels[first_match_index] = skillLevel
                                    length = len(known_face_names) # write to file
                                    file = open("data.txt","w")
                                    for i in range(length): 
                                        TempUser = (known_face_names[i]+';'+str(known_face_ages[i])+';'+str(known_face_skill_levels[i])+';'+known_faces_imageUrls[i]+';\n')
                                        file.write(TempUser)
                                    file.close()                                  
                             age = known_face_ages[first_match_index]
                             user = ckname
                             confidence = 100     
                     elif(name != ckname):
                         if(confidence < 10):
                             ckname = name
                         else:
                             confidence = confidence - 10
                 else:
                    confidence = confidence - 10
                    if(confidence < 10):
                        confidence = 0
                        user = "NULL"
                        studentSkillLev = "0"
                        age = "NULL"  
                 face_names.append(name)
            

            if face_encodings == []:
                ckNull = ckNull + 1
                if(ckNull == 5):
                    confidence = confidence - 10
                    ckNull = 0
                if(confidence == 0):
                        confidence = 0
                        user = "NULL"
                        studentSkillLev = "0"
                        age = "NULL"
                        highestEmotion = "NULL"
                        avgEmotion = []
                        
            self.changeUser.emit(user,age,str(studentSkillLev),confidence)

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_detection.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,minSize=(30,30),flags=cv2.CASCADE_SCALE_IMAGE)
            canvas = np.zeros((250, 300, 3), dtype="uint8")
            frameClone = frame.copy()
            
            if len(faces) > 0:
                faces = sorted(faces, reverse=True,
                key=lambda x: (x[2] - x[0]) * (x[3] - x[1]))[0]
                (fX, fY, fW, fH) = faces
                # Extract the ROI of the face from the grayscale image, resize it to a fixed 28x28 pixels, and then prepare
                # the ROI for classification via the CNN
                roi = gray[fY:fY + fH, fX:fX + fW]
                roi = cv2.resize(roi, (64, 64))
                roi = roi.astype("float") / 255.0
                roi = img_to_array(roi)
                roi = np.expand_dims(roi, axis=0)
                
                
                preds = emotion_classifier.predict(roi)[0]
                emotion_probability = np.max(preds)
                label = EMOTIONS[preds.argmax()]
            else: continue
            
            highestEmotionValue = 0.0
            for (i, (emotion, prob)) in enumerate(zip(EMOTIONS, preds)):
                        # construct the label text
                        text = "{}: {:.2f}%".format(emotion, prob * 100)
                        w = int(prob * 300)
                        cv2.rectangle(canvas, (7, (i * 35) + 5),
                        (w, (i * 35) + 35), (0, 0, 255), -1)
                        cv2.putText(canvas, text, (10, (i * 35) + 23),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                        (255, 255, 255), 2)
                        cv2.putText(frameClone, label, (fX, fY - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2)
                        cv2.rectangle(frameClone, (fX, fY), (fX + fW, fY + fH),
                                      (0, 0, 255), 2)

                        if float(highestEmotionValue) < float(w):
                            highestEmotion = emotion
                            highestEmotionValue = w

                        avgEmotion.append(highestEmotion)
                        if len(avgEmotion) > 75:
                            del avgEmotion[:firstElement]

            averageEmotion = ThreadFaceRecognition.most_frequent(avgEmotion)

            if(confidence < 10):
                highestEmotion = "NULL"

            self.updateEmotion.emit(averageEmotion)
       
## [Thread Number Provider]
class ThreadRandomNumbers(QtCore.QThread):
    updateNumbers = QtCore.pyqtSignal(int, int)

    def randomise(upperbound):
        valueOne = 0
        valueTwo = 0
        loop = True
        
        while loop == True:
            if valueOne == valueTwo:
                valueOne = random.randint(1, int(upperbound))
                valueTwo = random.randint(1, int(upperbound))
            else:
                loop = False
        return valueOne, valueTwo    
        
    def run(self):
        while True:
            if confidenceLevel == 100:
                 valueOne, valueTwo = ThreadRandomNumbers.randomise(skillLevel)
                 self.updateNumbers.emit(valueOne, valueTwo)
                 break

    
## [Activity Window]
class ActivityPage(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        [...]
        self.initUi()
        
    @QtCore.pyqtSlot(QtGui.QImage)
    def setImage(self, image):
        self.cameraPlaceholder.setPixmap(QtGui.QPixmap.fromImage(image))

    @QtCore.pyqtSlot(str, str, str, int)
    def setUser(self, user, age, studentskilllev, confidence):
        self.nameLabel.setText(user)
        self.ageLabel.setText(age)
        self.skillLabel.setText(studentskilllev)  
        self.confidenceBar.setProperty("value", confidence)
        if int(float(studentskilllev)) == 0:
            self.activityWindow.setStyleSheet("background-image: url(scenes/backgroundReady.png);")
        if int(float(studentskilllev)) == 10:
            self.activityWindow.setStyleSheet("background-image: url(scenes/background10.png);")
        if int(float(studentskilllev)) == 15:
            self.activityWindow.setStyleSheet("background-image: url(scenes/background15.png);")
        if int(float(studentskilllev)) == 20:
            self.activityWindow.setStyleSheet("background-image: url(scenes/background20.png);")
            
        global confidenceLevel
        confidenceLevel = confidence
        global skillLevel
        skillLevel = studentskilllev
        
        if user == "NULL":
            self.numberOne.hide()
            self.numberTwo.hide()
            self.feedbackIcon.hide()
            correctCounter = 0
            wrongCounter = 0
        else:
            self.numberOne.show()
            self.numberTwo.show()
            self.feedbackIcon.show()
            
    @QtCore.pyqtSlot(str)
    def setEmotion(self, averageEmotion):
        self.emotionLabel.setText(averageEmotion)

    @QtCore.pyqtSlot(int, int)
    def setValues(self, valueOne, valueTwo):
        self.valueOne = self.numberOne.setText(str(valueOne))        
        self.valueTwo = self.numberTwo.setText(str(valueTwo))

    def showTeacherWindowl(self):
        self.tp = TeacherPanel(self)
        self.tp.show()
    
    def center(self):
        qr = self.frameGeometry()
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def checkValues(self, valueOne, valueTwo, emotionLabel, nameLabel):
        global correctCounter, wrongCounter, skillLevel
        valueOne = int(valueOne.text())
        valueTwo = int(valueTwo.text())
        emotionState = str(emotionLabel.text())
   
        if valueOne > valueTwo:
            pixmap = QtGui.QPixmap('icons/happy.png')
            self.feedbackIcon.setPixmap(pixmap)
            correctCounter = correctCounter + 1
        
        else:
            pixmap = QtGui.QPixmap('icons/sad.png')
            self.feedbackIcon.setPixmap(pixmap)
            wrongCounter = wrongCounter + 1
                    
        if(correctCounter == 10):
            if(wrongCounter <= 2):
                wrongCounter = 0
                correctCounter = 0
                if(int(skillLevel) != 20): #if 10 right and less than 2 wrong level up
                    skillLevel = int(skillLevel) + 5

                    userUpdate = (str(nameLabel.text())+';has increased their level to: '+str(skillLevel))
                    with open("log.txt", "a+") as file_object:
                        file_object.seek(0)
                        data = file_object.read(100)
                        if len(data) > 0 :
                            file_object.write("\n")
                        file_object.write(userUpdate)
                    
                else:
                    userUpdate = (str(nameLabel.text())+';is exceeding EYFS goals')
                    with open("log.txt", "a+") as file_object:
                        file_object.seek(0)
                        data = file_object.read(100)
                        if len(data) > 0 :
                            file_object.write("\n")
                        file_object.write(userUpdate)
 
            else:
                wrongCounter = 0 #do nothing if more than 2 wrong and 10 right
                correctCounter = 0
                userUpdate = (str(nameLabel.text())+';has attempted level'+str(skillLevel)+' but still is not confident')
                with open("log.txt", "a+") as file_object:
                    file_object.seek(0)
                    data = file_object.read(100)
                    if len(data) > 0 :
                        file_object.write("\n")
                    file_object.write(userUpdate)
        else:
            if(wrongCounter >= 5):
                if(int(skillLevel) != 10): #if more than 4 wrong level down
                    if(emotionState == "angry") or (emotionState == "upset") or (emotionState == "disgust") or (emotionState == "scared"):
                        skillLevel = int(skillLevel) - 5
                        userUpdate = (str(nameLabel.text())+';has decreased their level to: '+str(skillLevel))
                        with open("log.txt", "a+") as file_object:
                            file_object.seek(0)
                            data = file_object.read(100)
                            if len(data) > 0 :
                                file_object.write("\n")
                            file_object.write(userUpdate)
                        
                wrongCounter = 0
                correctCounter = 0
                pixmap = QtGui.QPixmap('icons/teacher.png')
                self.feedbackIcon.setPixmap(pixmap)
                
        results = (correctCounter, wrongCounter)    
        self.correctCount.setText(str(results))                
        threadRnd = ThreadRandomNumbers(self)
        threadRnd.updateNumbers.connect(self.setValues)
        threadRnd.start()
        
    def initUi(self):
        self.resize(1000, 630)
        self.center()
        self.setAutoFillBackground(False)
        self.setStyleSheet("background-color: rgb(252, 233, 79);")
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")

        self.cameraPlaceholder = QtWidgets.QLabel(self) #camera feed
        self.cameraPlaceholder.setGeometry(QtCore.QRect(870, 10, 100, 100))
        self.cameraPlaceholder.setObjectName("cameraPlaceholder")
        
        threadStream = ThreadCamView(self)
        threadStream.changePixmap.connect(self.setImage)
        threadStream.start()
    
        threadFacialRec = ThreadFaceRecognition(self)
        threadFacialRec.changeUser.connect(self.setUser)
        threadFacialRec.updateEmotion.connect(self.setEmotion)
        threadFacialRec.start()

        self.valueOne = ""
        self.valueTwo = ""
        threadRnd = ThreadRandomNumbers(self)
        threadRnd.updateNumbers.connect(self.setValues)
        threadRnd.start()
        
        self.activityWindow = QtWidgets.QFrame(self.centralwidget)
        self.activityWindow.setGeometry(QtCore.QRect(30, 130, 941, 471))
        self.activityWindow.setStyleSheet("background-image: url(scenes/backgroundLoad.png);")
        self.activityWindow.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.activityWindow.setFrameShadow(QtWidgets.QFrame.Raised)
        self.activityWindow.setObjectName("activityWindow")
        
        fontTitle = QtGui.QFont()
        fontTitle.setFamily("Chilanka")
        fontTitle.setPointSize(15)
        fontTitle.setBold(True)
        fontTitle.setWeight(75)
        
        fontPlaceholder = QtGui.QFont()
        fontPlaceholder.setFamily("Chilanka")
        fontPlaceholder.setPointSize(15)
        fontPlaceholder.setBold(False)
        fontPlaceholder.setWeight(50)
        
        fontBar = QtGui.QFont()
        fontBar.setFamily("Chilanka")
        fontBar.setPointSize(11)
        fontBar.setBold(False)
        fontBar.setItalic(True)
        fontBar.setWeight(50)
        
        fontQuestion = QtGui.QFont()
        fontQuestion.setFamily("Chilanka")
        fontQuestion.setPointSize(20)
        fontQuestion.setBold(True)

        self.nameTitleLabel = QtWidgets.QLabel(self.centralwidget)
        self.nameTitleLabel.setGeometry(QtCore.QRect(30, 20, 67, 31))
        self.nameTitleLabel.setFont(fontTitle)
        self.nameTitleLabel.setObjectName("nameTitleLabel")

        self.nameLabel = QtWidgets.QLabel(self.centralwidget)
        self.nameLabel.setGeometry(QtCore.QRect(150, 20, 271, 31))
        self.nameLabel.setFont(fontPlaceholder)
        self.nameLabel.setObjectName("nameLabel")

        self.ageTitleLabel = QtWidgets.QLabel(self.centralwidget)
        self.ageTitleLabel.setGeometry(QtCore.QRect(30, 50, 67, 31))
        self.ageTitleLabel.setFont(fontTitle)
        self.ageTitleLabel.setObjectName("ageTitleLabel")

        self.ageLabel = QtWidgets.QLabel(self.centralwidget)
        self.ageLabel.setGeometry(QtCore.QRect(150, 50, 271, 31))
        self.ageLabel.setFont(fontPlaceholder)
        self.ageLabel.setObjectName("ageLabel")

        self.skillTitleLabel = QtWidgets.QLabel(self.centralwidget)
        self.skillTitleLabel.setGeometry(QtCore.QRect(30, 80, 97, 31))
        self.skillTitleLabel.setFont(fontTitle)
        self.skillTitleLabel.setObjectName("skillTitleLabel")

        self.skillLabel = QtWidgets.QLabel(self.centralwidget)
        self.skillLabel.setGeometry(QtCore.QRect(150, 80, 271, 31))
        self.skillLabel.setFont(fontPlaceholder)
        self.skillLabel.setObjectName("skillLabel")

        self.confidenceBar = QtWidgets.QProgressBar(self.centralwidget)
        self.confidenceBar.setGeometry(QtCore.QRect(550, 20, 201, 23))
        self.confidenceBar.setFont(fontBar)
        self.confidenceBar.setStyleSheet("background-color: rgb(238, 238, 236);")
        self.confidenceBar.setProperty("value", 0)
        self.confidenceBar.setTextVisible(True)
        self.confidenceBar.setInvertedAppearance(False)
        self.confidenceBar.setTextDirection(QtWidgets.QProgressBar.TopToBottom)
        self.confidenceBar.setObjectName("confidenceBar")

        self.confidenceTitleLabel = QtWidgets.QLabel(self.centralwidget)
        self.confidenceTitleLabel.setGeometry(QtCore.QRect(410, 20, 121, 31))
        self.confidenceTitleLabel.setFont(fontTitle)
        self.confidenceTitleLabel.setObjectName("confidenceTitleLabel")

        self.emotionTitleLabel = QtWidgets.QLabel(self.centralwidget)
        self.emotionTitleLabel.setGeometry(QtCore.QRect(410, 50, 200, 31))     
        self.emotionTitleLabel.setFont(fontTitle)
        self.emotionTitleLabel.setObjectName("emotionTitleLabel")

        self.emotionLabel = QtWidgets.QLabel(self.centralwidget)
        self.emotionLabel.setGeometry(QtCore.QRect(550, 50, 121, 31))
        self.emotionLabel.setFont(fontPlaceholder)
        self.emotionLabel.setObjectName("emotionLabel")

        self.correctCount = QtWidgets.QLabel(self.centralwidget)
        self.correctCount.setGeometry(QtCore.QRect(550, 80, 121, 31))
        self.correctCount.setFont(fontPlaceholder)
        self.correctCount.setObjectName("correctCount")

        self.correctCountTitle = QtWidgets.QLabel(self.centralwidget)
        self.correctCountTitle.setGeometry(QtCore.QRect(410, 80, 121, 31))
        self.correctCountTitle.setFont(fontTitle)
        self.correctCountTitle.setObjectName("correctCountTitle")
        
        self.questionPlaceholder = QtWidgets.QLabel(self.centralwidget)
        self.questionPlaceholder.setGeometry(QtCore.QRect(100, 220, 521, 40))
        self.questionPlaceholder.setStyleSheet("background: transparent;;")
        self.questionPlaceholder.setFont(fontQuestion)
        
        self.questionOr = QtWidgets.QLabel(self.centralwidget)
        self.questionOr.setGeometry(QtCore.QRect(440, 320, 70, 90))
        self.questionOr.setStyleSheet("background: transparent;")
        fontQuestion.setPointSize(40)
        self.questionOr.setFont(fontQuestion)

        self.numberOne = QtWidgets.QPushButton(self.centralwidget)
        self.numberOne.setGeometry(QtCore.QRect(200, 330, 121, 90))
        self.numberOne.setStyleSheet("background-color: rgba(255, 255, 255, 0)")
        fontQuestion.setPointSize(50)
        self.numberOne.setFont(fontQuestion)
        self.numberOne.clicked.connect(lambda: self.checkValues(self.numberOne, self.numberTwo, self.emotionLabel, self.nameLabel))

        self.numberTwo = QtWidgets.QPushButton(self.centralwidget)
        self.numberTwo.setGeometry(QtCore.QRect(590, 330, 121, 90))
        self.numberTwo.setStyleSheet("background-color: rgba(255, 255, 255, 0)")
        self.numberTwo.setFont(fontQuestion)
        self.numberTwo.clicked.connect(lambda: self.checkValues(self.numberTwo, self.numberOne,self. emotionLabel, self.nameLabel)) 

        self.feedbackIcon = QtWidgets.QLabel(self.centralwidget)
        self.feedbackIcon.setGeometry(QtCore.QRect(420, 450, 100, 100))
        self.feedbackIcon.setStyleSheet("background: transparent;")

        self.btnSettings = QtWidgets.QPushButton(self.centralwidget)
        self.btnSettings.setGeometry(QtCore.QRect(800, 20, 50, 50))
        self.btnSettings.setStyleSheet("background-color: rgb(138, 226, 52)")
        self.btnSettings.setIcon(QtGui.QIcon('icons/settings.png'))
        self.btnSettings.setIconSize(QtCore.QSize(40,40))
        self.btnSettings.clicked.connect(self.showTeacherWindowl)
        
        self.setWindowTitle("Activity Page")
        self.nameTitleLabel.setText("Name:")
        self.nameLabel.setText("Unknown")
        self.ageTitleLabel.setText("Age:")
        self.ageLabel.setText("Unknown")
        self.skillTitleLabel.setText("Skill Level:")
        self.skillLabel.setText("Unknown")
        self.confidenceTitleLabel.setText("Confidence:")
        self.emotionTitleLabel.setText("Avg Emotion:")
        self.emotionLabel.setText("Unknown")
        self.correctCount.setText("0")
        self.correctCountTitle.setText("Count (✔, ✘):")
        self.questionPlaceholder.setText("Choose the bigger number?")
        self.numberOne.setText("")
        self.numberTwo.setText("")
        self.questionOr.setText("or")
        self.show()

## [Teacher Page]
class TeacherPanel(QtWidgets.QMainWindow):
    def __init__(self, parent):
        super(TeacherPanel, self).__init__(parent)
        [...]
        self.initUi()

        
    def hideTeacherPanel(self):
        self.hide()

    def center(self):
        qr = self.frameGeometry()
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def populateList(self):
        self.listStudents.clear()
        file = open("data.txt","r")
        for line in file:
          fields = line.split(";")
          studentName = fields[0]
          self.listStudents.addItem(studentName)
        file.close()

    def listwidgetclicked(self, item):
        file = open("data.txt","r")
        for line in file:
          fields = line.split(";")
          studentName = fields[0]
          studentAge = fields[1]
          studentSkillLev = fields[2]
          studentImgLocation = fields[3]
          if(item.text() == studentName):
              self.nameEdit.setText(studentName)
              self.urlEdit.setText(studentImgLocation)
              self.skillEdit.setText(studentSkillLev)
              self.ageEdit.setText(studentAge)
              pngfile = QtGui.QPixmap(studentImgLocation)
              self.imagePlaceholder.setPixmap(pngfile)
            
        file = open("log.txt","r")
        self.logList.clear()
        for line in file:
            fields = line.split(";")
            studentName = fields[0]
            update = fields[1]
            if(item.text() == studentName):
                self.logList.addItem(update)
        file.close()

    def updateStudentDetails(self, item):
        newAge = self.ageEdit.text()
        newSkill = self.skillEdit.text()
        newUrl = self.urlEdit.text()
        sName = []
        sAge = []
        sSkillLev = []
        sImgLocation = []

        file = open("data.txt","r")
        lum = 0
        for line in file:
            fields = line.split(";")
            sName.append(fields[0])
            sAge.append(fields[1])
            sSkillLev.append(fields[2])
            sImgLocation.append(fields[3])
            if(self.nameEdit.text() == sName[lum]):
                sAge[lum] = newAge
                sSkillLev[lum] = newSkill
                sImgLocation[lum] = newUrl
            lum += 1
        file.close()
        length = len(sName) # write to file
        file = open("data.txt","w")
        for i in range(length): 
            TempUser = (sName[i]+';'+str(sAge[i])+';'+str(sSkillLev[i])+';'+sImgLocation[i]+';\n')
            file.write(TempUser)
        file.close()
            

    def getImage(self):
        fname = QtWidgets.QFileDialog.getOpenFileName(self, "Open file", "c:", "Image files (*.jpg *.gif)")
        imagePath = fname[0]
        pixmap = QtGui.QPixmap(imagePath)
        self.imagePlaceholder.setPixmap(QtGui.QPixmap(pixmap))
        self.urlEdit.setText(imagePath)

    def addStudent(self):
        name, done1 = QtWidgets.QInputDialog.getText(self, "Input Dialog", "enter student's name:")  
        age, done2 = QtWidgets.QInputDialog.getInt(self, "Input Dialog", "enter student's age:")
        skills =['10', '15', '20'] 
        skill, done3 = QtWidgets.QInputDialog.getItem(self, 'Input Dialog', "enter student's skill level (max known):", skills) 
        url, done4 = QtWidgets.QInputDialog.getText(self, 'Input Dialog', "enter student's image URL:") 
        if done1 and done2 and done3 and done4 : 
             newUser = (str(name)+';'+str(age)+';'+str(skill)+';'+str(url)+';')
             self.listStudents.addItem(name)
             with open("data.txt", "a+") as file_object:
                file_object.seek(0)
                data = file_object.read(100)
                '''if len(data) > 0 :
                    file_object.write("\n")'''
                file_object.write(newUser)
                                            
    def initUi(self):
        self.resize(1000, 630)
        self.center()
        self.setStyleSheet("background-color: rgb(252, 233, 79);")
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.setCentralWidget(self.centralwidget)
        self.setWindowTitle("Teacher Panel")

        fontTitle = QtGui.QFont()
        fontTitle.setFamily("Chilanka")
        fontTitle.setPointSize(12)
        fontTitle.setBold(True)
        fontTitle.setWeight(75)
        
        fontPlaceholder = QtGui.QFont()
        fontPlaceholder.setFamily("Chilanka")
        fontPlaceholder.setPointSize(12)
        fontPlaceholder.setBold(False)
        fontPlaceholder.setWeight(50)
        
        self.listStudents = QtWidgets.QListWidget(self.centralwidget)
        self.listStudents.setGeometry(QtCore.QRect(30, 90, 281, 471))
        self.listStudents.setStyleSheet("background-color: rgb(173, 127, 168);")
        self.listStudents.setObjectName("listStudents")
        self.listStudents.setFont(fontPlaceholder)
        TeacherPanel.populateList(self)
        self.listStudents.itemClicked.connect(self.listwidgetclicked)

        self.detailsFrame = QtWidgets.QFrame(self.centralwidget)
        self.detailsFrame.setGeometry(QtCore.QRect(330, 90, 641, 511))
        self.detailsFrame.setStyleSheet("background-color: rgb(138, 226, 52);")
        self.detailsFrame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.detailsFrame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.detailsFrame.setObjectName("detailsFrame")

        self.returnButton = QtWidgets.QPushButton(self)
        self.returnButton.setGeometry(QtCore.QRect(920, 20, 50, 50))
        self.returnButton.setStyleSheet("background-color: rgb(138, 226, 52);")
        self.returnButton.setObjectName("returnButton")
        self.returnButton.setIcon(QtGui.QIcon('icons/return.png'))
        self.returnButton.setIconSize(QtCore.QSize(40,40))
        self.returnButton.setFont(fontPlaceholder)
        self.returnButton.clicked.connect(self.hideTeacherPanel)
        
        self.studentName = QtWidgets.QLabel(self.detailsFrame)
        self.studentName.setGeometry(QtCore.QRect(30, 40, 191, 21))
        self.studentName.setObjectName("studentName")
        self.studentName.setText("Name:")
        self.studentName.setFont(fontTitle)

        self.nameEdit = QtWidgets.QLineEdit(self.detailsFrame)
        self.nameEdit.setGeometry(QtCore.QRect(140, 40, 201, 25))
        self.nameEdit.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.nameEdit.setObjectName("nameEdit")
        self.nameEdit.setText("Unknown")
        self.nameEdit.setFont(fontPlaceholder)

        self.ageLabelTitle = QtWidgets.QLabel(self.detailsFrame)
        self.ageLabelTitle.setGeometry(QtCore.QRect(30, 80, 51, 31))
        self.ageLabelTitle.setObjectName("ageLabelTitle")
        self.ageLabelTitle.setText("Age:")
        self.ageLabelTitle.setFont(fontTitle)
        
        self.skillLabelTitle = QtWidgets.QLabel(self.detailsFrame)
        self.skillLabelTitle.setGeometry(QtCore.QRect(30, 120, 51, 31))
        self.skillLabelTitle.setObjectName("skillLabelTitle")
        self.skillLabelTitle.setText("Skill:")
        self.skillLabelTitle.setFont(fontTitle)
        
        self.urlLabelTitle = QtWidgets.QLabel(self.detailsFrame)
        self.urlLabelTitle.setGeometry(QtCore.QRect(30, 160, 101, 31))
        self.urlLabelTitle.setObjectName("urlLabelTitle")
        self.urlLabelTitle.setText("Image URL:")
        self.urlLabelTitle.setFont(fontTitle)
        
        self.updateButton = QtWidgets.QPushButton(self.detailsFrame)
        self.updateButton.setGeometry(QtCore.QRect(488, 464, 141, 41))
        self.updateButton.setObjectName("updateButton")
        self.updateButton.setText("Save All")
        self.updateButton.setFont(fontPlaceholder)
        self.updateButton.clicked.connect(self.updateStudentDetails)
        
        self.imageFrame = QtWidgets.QFrame(self.detailsFrame)
        self.imageFrame.setGeometry(QtCore.QRect(425, 75, 141, 201))
        self.imageFrame.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.imageFrame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.imageFrame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.imageFrame.setObjectName("imageFrame")

        self.imagePlaceholder = QtWidgets.QLabel(self.detailsFrame)
        self.imagePlaceholder.setGeometry(QtCore.QRect(425, 75, 141, 201))
        self.imagePlaceholder.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.imagePlaceholder.setObjectName("imageFrame")
        self.imagePlaceholder.setScaledContents(True)
        
        self.photoUpdateButton = QtWidgets.QPushButton(self.detailsFrame)
        self.photoUpdateButton.setGeometry(QtCore.QRect(425, 280, 141, 31))
        self.photoUpdateButton.setStyleSheet("background-color: rgb(138, 226, 52);")
        self.photoUpdateButton.setObjectName("photoUpdateButton")
        self.photoUpdateButton.setText("Update Image")
        self.photoUpdateButton.setFont(fontPlaceholder)
        self.photoUpdateButton.clicked.connect(self.getImage)
        
        self.ageEdit = QtWidgets.QLineEdit(self.detailsFrame)
        self.ageEdit.setGeometry(QtCore.QRect(140, 80, 201, 25))
        self.ageEdit.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.ageEdit.setObjectName("ageEdit")
        self.ageEdit.setText("Unknown")
        self.ageEdit.setFont(fontPlaceholder)
        
        self.skillEdit = QtWidgets.QLineEdit(self.detailsFrame)
        self.skillEdit.setGeometry(QtCore.QRect(140, 120, 201, 25))
        self.skillEdit.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.skillEdit.setObjectName("skillEdit")
        self.skillEdit.setText("Unknown")
        self.skillEdit.setFont(fontPlaceholder)
        
        self.urlEdit = QtWidgets.QLineEdit(self.detailsFrame)
        self.urlEdit.setGeometry(QtCore.QRect(140, 160, 201, 25))
        self.urlEdit.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.urlEdit.setCursor(QtGui.QCursor(QtCore.Qt.ForbiddenCursor))
        self.urlEdit.setObjectName("urlEdit")
        self.urlEdit.setText("Unknown")
        self.urlEdit.setFont(fontPlaceholder)
        
        self.imageLabelTitle = QtWidgets.QLabel(self.detailsFrame)
        self.imageLabelTitle.setGeometry(QtCore.QRect(425, 40, 71, 31))
        self.imageLabelTitle.setObjectName("imageLabelTitle")
        self.imageLabelTitle.setText("Photo:")
        self.imageLabelTitle.setFont(fontTitle)
        
        self.addStudentButton = QtWidgets.QPushButton(self.centralwidget)
        self.addStudentButton.setGeometry(QtCore.QRect(30, 560, 281, 41))
        self.addStudentButton.setStyleSheet("background-color: rgb(173, 127, 168);")
        self.addStudentButton.setObjectName("addStudentButton")
        self.addStudentButton.setText("Add Student +")
        self.addStudentButton.setFont(fontPlaceholder)
        self.addStudentButton.clicked.connect(self.addStudent)

        self.logLabelTitle = QtWidgets.QLabel(self.detailsFrame)
        self.logLabelTitle.setGeometry(QtCore.QRect(30, 250, 300, 31))
        self.logLabelTitle.setObjectName("logLabelTitle")
        self.logLabelTitle.setText("Log of User Activity (newest at bottom):")
        self.logLabelTitle.setFont(fontTitle)

        self.logList = QtWidgets.QListWidget(self.detailsFrame)
        self.logList.setStyleSheet("background-color: rgb(211, 215, 207);")
        self.logList.setGeometry(QtCore.QRect(30, 290, 320, 200))
        self.logList.setObjectName("logList")
        self.logList.setFont(fontPlaceholder)

        self.teacherTitle = QtWidgets.QLabel(self.centralwidget)
        self.teacherTitle.setGeometry(QtCore.QRect(420, 30, 231, 41))
        self.teacherTitle.setObjectName("teacherTitle")
        self.teacherTitle.setText("Teacher Panel")
        fontTitle.setPointSize(18)
        self.teacherTitle.setFont(fontTitle)

        
## [Initialise Program]
def main():
    app = QtWidgets.QApplication(sys.argv)
    execute = ActivityPage()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
